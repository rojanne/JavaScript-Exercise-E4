const divContent = document.getElementById("content");
let stringHTML = "";

function dogYears(humanAge) {
    var dogAge = parseInt(humanAge * 7);
    return dogAge;
}

var dogs = [
    {
        "name" : "Sushi",
        "age" : dogYears(1),
        "image": "https://www.akc.org/wp-content/uploads/2016/06/German-Shepherd-Dog-laying-down-in-the-backyard-500x487.jpeg",
        "toys" : ["bone","water bottle"],
    },
    {
        "name" : "Dosan",
        "age" : dogYears(1),
        "image": "https://thehappypuppysite.com/wp-content/uploads/2018/02/lemon-beagle-1.jpg",
        "toys" : ["Ball","Shoes"],
    },
    {
        "name" : "Moonchin",
        "age" : dogYears(2),
        "image": "https://www.miracleshihtzu.com/images/Shih-Tzu-Puppy-White.jpg",
        "toys" : ["Ducklings","Tabo"],
    }       
]

for (i = 0; i < dogs.length; i++) {
    stringHTML +=`
    <div class="list">
        <div class="column">
            Name: ${dogs[i].name} <br><br>
            Age: Your doggie is ${dogs[i].age} years old in dog years! <br><br>
            <img src="${dogs[i].image}"> <br><br>
            fave toys: ${dogs[i].toys} <br><br>
        </div>
    </div>
    `;
    
}
divContent.innerHTML = stringHTML;